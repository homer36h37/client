<?php

class TestController extends Controller_Action {

	public function indexAction() {}
}